 os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings")
